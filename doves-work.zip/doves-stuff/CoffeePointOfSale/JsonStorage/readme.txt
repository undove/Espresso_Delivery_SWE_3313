﻿1) This directory will be created  under the BIN folder.
2) JSON will be stored in the BIN/JsonStorage directory.
3) The StorageService.Read method will create a JSON file equal to the name of your class IF the file does not already exist. For example Customers will have a Customers.json file.