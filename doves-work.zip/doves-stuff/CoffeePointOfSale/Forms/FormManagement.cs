﻿using CsvHelper;
using CoffeePointOfSale.Configuration;
using CoffeePointOfSale.Forms.Base;
using CoffeePointOfSale.Services.Customer;
using CoffeePointOfSale.Services.FormFactory;
using System.Diagnostics;
using System.Globalization;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace CoffeePointOfSale.Forms;

public partial class FormManagement : FormNoCloseBase
{
    private readonly ICustomerService _customerService;
    private IAppSettings _appSettings;

    public FormManagement(IAppSettings appSettings, ICustomerService customerService) : base(appSettings)
    {
        _customerService = customerService;
        _appSettings = appSettings;
        InitializeComponent();
    }

    private void OnClickBtnClose(object sender, EventArgs e)
    {
        Close(); //closes this form
        FormFactory.Get<FormMain>().Show(); //re-opens the main form
    }

    private void OnClickBtnSalesReport(object sender, EventArgs e)
    {
        ConvertToCSV();
    }

    /// <summary>
    /// Converts the JSON information to a CSV file and then opens that in Excel.
    /// </summary>
    private void ConvertToCSV()
    {
        var csvList = new List<CSVExtract>();

        //customers x orders x drinks
        foreach (var customer in _customerService.Customers.List)
        {
            foreach (var order in customer.Orders)
            {
                var input = new CSVExtract
                {
                    Phone = customer.Phone,
                    FirstName = customer.FirstName,
                    LastName = customer.LastName,
                    RPBal = customer.RewardPointsBalance,
                    DateTime = order.DateTime,
                    Subtotal = order.Subtotal,
                    Tax = order.Tax,
                    Total = order.Total,
                    PayMethod = order.PaymentMethod,
                    PayDetails = order.PaymentDetails,
                    PointsEarned = order.PointsEarned,
                    OrderInfo = order.ToString()
                };
    
                csvList.Add(input);
            }
        }


        var dir = Path.GetTempPath();
        var fn = $"TestCsv -{DateTime.Now:yyyy - MM - dd - HH - mm - s}.csv";
        var csvPath = Path.Join(dir, fn);
        using (var writer = new StreamWriter(csvPath))
        using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
        {
            csv.WriteRecords(csvList);
        }


        try
        {
            var processStartInfo = new ProcessStartInfo(csvPath);
            processStartInfo.WorkingDirectory = dir;
            processStartInfo.UseShellExecute = true;
            Process.Start(processStartInfo);

        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to open: {ex.Message}");
        }

    }
}

