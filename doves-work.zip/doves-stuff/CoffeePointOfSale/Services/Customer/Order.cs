﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeePointOfSale.Services.Customer
{
    public class Order
    {
        public DateTime? DateTime { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Tax { get; set; }
        public decimal Total { get; set; }
        public int PointsEarned { get; set; }
        public string? PaymentMethod { get; set; }
        public string? PaymentDetails { get; set; }
        public List<Drink> Drinks { get; set; } = new();

        public override string ToString()
        {
            //join all of the drinks together using the Drink ToString method
            return string.Join(" || ", Drinks);
        }
    }
}
