﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeePointOfSale.Services.Customer
{
    public class Drink
    {
        public string? Name { get; set; }
        public decimal? BasePrice { get; set; }
        public decimal? TotalPrice { get; set; }
        public List<string> Customizations { get; set; } = new();

        public override string ToString()
        {
            var drink = "";
            drink += Name + ", Base Price: " + BasePrice + ", Total Price: " + TotalPrice + " [";
            if (Customizations.Count > 0)
            {
                drink += " " + string.Join(", ", Customizations);
            }
            drink += "] ";
            return drink;
        }
    }
}
