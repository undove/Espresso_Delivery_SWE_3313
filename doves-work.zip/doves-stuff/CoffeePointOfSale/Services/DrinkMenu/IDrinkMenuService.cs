﻿namespace CoffeePointOfSale.Services.DrinkMenu;

public interface IDrinkMenuService { }