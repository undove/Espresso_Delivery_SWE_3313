﻿namespace CoffeePointOfSale.Configuration;

public class Rewards
{
    public decimal PointsPerDollar { get; init; }
}