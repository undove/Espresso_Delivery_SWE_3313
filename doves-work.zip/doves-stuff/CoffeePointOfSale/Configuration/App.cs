﻿namespace CoffeePointOfSale.Configuration;

public class App
{
    public string Name { get; init; } = "App AnonymousCustomerId Not Set";
}