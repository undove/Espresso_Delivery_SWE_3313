﻿namespace CoffeePointOfSale.Configuration;

public class Tax
{
    public decimal Rate { get; set; }
}